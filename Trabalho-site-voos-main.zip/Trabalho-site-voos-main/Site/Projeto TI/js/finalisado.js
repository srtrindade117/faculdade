document.getElementById('newPurchase').addEventListener('click', function() {
    // Redireciona para a página inicial ou de compras
    window.location.href = '../html/index.html'; // Substitua pelo caminho da sua página inicial
});
